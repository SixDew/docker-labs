-- Создаем базу данных, если она не существует
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'mydatabase') THEN
        CREATE DATABASE mydatabase;
    END IF;
END $$;

-- Подключаемся к базе данных
\c mydatabase;

-- Создаем таблицу, если она не существует
CREATE TABLE IF NOT EXISTS mytable (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    age INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);