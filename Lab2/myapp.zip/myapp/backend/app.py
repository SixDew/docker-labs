from flask import Flask, render_template, request, redirect, url_for
import psycopg2
from datetime import datetime

app = Flask(__name__)

DB_HOST = 'db'
DB_NAME = 'mydatabase'
DB_USER = 'postgres'
DB_PASS = 'password'

def get_db_connection():
    conn = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM mytable ORDER BY created_at DESC;')
    data = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('index.html', data=data)

@app.route('/contacts')
def contacts():
    return render_template('contacts.html')

@app.route('/add', methods=['POST'])
def add():
    name = request.form['name']
    email = request.form['email']
    age = request.form['age']
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO mytable (name, email, age) VALUES (%s, %s, %s)',
        (name, email, age)
    )
    conn.commit()
    cur.close()
    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)